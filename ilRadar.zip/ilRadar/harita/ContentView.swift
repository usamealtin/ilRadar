import SwiftUI
import UIKit

struct ContentView: View {
    @State private var passport: PassportStore
    @State private var engine: GameEngine
    @State private var showPassport = false

    init() {
        let store = PassportStore()
        _passport = State(initialValue: store)
        _engine = State(initialValue: GameEngine(passport: store))
    }

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    colors: [
                        Color(red: 0.03, green: 0.06, blue: 0.13),
                        Color(red: 0.06, green: 0.11, blue: 0.21)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                VStack(spacing: 10) {
                    // Merkez: Genişletilmiş Vektörel Harita + Köşede Yüzen Hedef Kartı
                    ZStack(alignment: .topLeading) {
                        TurkeyMapView(
                            provinces: TurkeyData.provinces,
                            foundIDs: engine.foundIDs,
                            wrongFlashID: engine.wrongFlashID,
                            highlightedID: engine.lastFoundID,
                            isBlindMode: engine.mode == .blindMap,
                            isTapMode: true
                        ) { province in
                            engine.handleMapTap(province)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)

                        // Sol Üst Köşede Yüzen Hedef Şehir Kartı
                        floatingTargetCard
                            .padding(10)

                        // Blitz Bekleme Ekranı Uyarısı
                        if engine.mode == .blitz && engine.isWaitingToStart {
                            Color.black.opacity(0.42)
                                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                                .onTapGesture {
                                    engine.triggerBlitzStart()
                                }

                            VStack(spacing: 8) {
                                Image(systemName: "hand.tap.fill")
                                    .font(.system(size: 32))
                                    .foregroundStyle(.cyan)
                                Text("60 Saniye Blitz")
                                    .font(.headline.bold())
                                    .foregroundStyle(.white)
                                Text("Başlamak için haritaya dokun")
                                    .font(.subheadline)
                                    .foregroundStyle(.white.opacity(0.8))
                            }
                            .padding(20)
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .allowsHitTesting(false)
                        }

                        // Sağ Alt Köşede Hızlı Geri Bildirim Kapsülü
                        if let banner = engine.feedbackBanner {
                            VStack {
                                Spacer()
                                HStack {
                                    Spacer()
                                    Text(banner)
                                        .font(.caption.bold())
                                        .padding(.horizontal, 12)
                                        .padding(.vertical, 7)
                                        .background(.ultraThinMaterial, in: Capsule())
                                        .overlay(
                                            Capsule().strokeBorder(.white.opacity(0.2), lineWidth: 1)
                                        )
                                        .foregroundStyle(.white)
                                }
                            }
                            .padding(12)
                            .allowsHitTesting(false)
                            .transition(.opacity)
                        }
                    }

                    // Alt İstatistik Barı
                    statsBar
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
            }
            .navigationTitle("İlRadar")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                // Sol: Ustalık Pasaportu
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        showPassport = true
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: "globe.europe.africa.fill")
                            Text("\(passport.masteredIDs.count)/81")
                                .font(.caption.bold())
                        }
                        .foregroundStyle(.cyan)
                    }
                }

                // ÖĞRETİCİ NOT 1: .principal yerleşimi menüyü üst barın tam ortasına oturtur
                ToolbarItem(placement: .principal) {
                    modeSelectorMenu
                }

                // Sağ: Mevcut Oyunu Sıfırla
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        engine.startNewGame(mode: engine.mode)
                    } label: {
                        Image(systemName: "arrow.counterclockwise")
                            .foregroundStyle(.white)
                    }
                }
            }
            .sheet(isPresented: $showPassport) {
                PassportView(passport: passport)
            }
            .sheet(isPresented: $engine.isGameOver) {
                gameOverSheet
                    .presentationDetents([.medium])
            }
        }
        .preferredColorScheme(.dark)
    }

    // MARK: - Tek Kapsül + Açılır Oyun Modu Menüsü
    private var modeSelectorMenu: some View {
        Menu {
            ForEach(GameMode.allCases) { item in
                let isSelected = (item == engine.mode)

                Button {
                    UISelectionFeedbackGenerator().selectionChanged()
                    if item != engine.mode {
                        engine.startNewGame(mode: item)
                    }
                } label: {
                    // ÖĞRETİCİ NOT 2: Menu içindeki Button'a iki Text verildiğinde
                    // iOS ikincisini otomatik olarak gri alt açıklama (subtitle) yapar.
                    Text(isSelected ? "✓ \(item.rawValue)" : item.rawValue)
                    Text(modeDescription(for: item))
                    Image(systemName: item.icon)
                }
            }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: engine.mode.icon)
                    .font(.caption.bold())
                    .foregroundStyle(.cyan)

                Text(engine.mode.rawValue)
                    .font(.subheadline.bold())
                    .foregroundStyle(.white)

                Image(systemName: "chevron.down")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(.white.opacity(0.6))
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 6)
            .background(.white.opacity(0.10), in: Capsule())
            .overlay(
                Capsule()
                    .strokeBorder(.cyan.opacity(0.35), lineWidth: 1)
            )
        }
    }

    private func modeDescription(for mode: GameMode) -> String {
        switch mode {
        case .classic: return "81 ilin tamamını haritada bul"
        case .plateHunt: return "Verilen plaka kodundan ili bul"
        case .blindMap: return "Bölge renkleri gizli, sadece sınırlar"
        case .detective: return "Coğrafi ipucundan doğru ili yakala"
        case .heritage: return "Tarihi ve kültürel mirastan ili bul"
        case .blitz: return "60 saniye içinde en yüksek skoru yap"
        case .survival: return "Sadece 3 hata hakkıyla ilerle"
        }
    }

    // MARK: - Köşedeki Yüzen Hedef Kartı
    private var floatingTargetCard: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(engine.promptBadge)
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(.cyan)

                Text(engine.promptTitle)
                    .font(engine.mode == .detective || engine.mode == .heritage ? .caption.bold() : .headline.bold())
                    .foregroundStyle(.white)
                    .lineLimit(2)
            }

            if !engine.isGameOver && !(engine.mode == .blitz && engine.isWaitingToStart) {
                Button {
                    engine.skipCurrent()
                } label: {
                    Image(systemName: "forward.fill")
                        .font(.caption.bold())
                        .padding(7)
                        .background(.white.opacity(0.15), in: Circle())
                        .foregroundStyle(.white)
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(.cyan.opacity(0.45), lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.35), radius: 8, y: 3)
        .frame(maxWidth: 260, alignment: .leading)
    }

    // MARK: - Alt İstatistik Barı
    private var statsBar: some View {
        HStack(spacing: 10) {
            statPill(title: "BULUNAN", value: "\(engine.foundIDs.count)/81", color: .mint)
            statPill(title: "SKOR", value: "\(engine.score)", color: .cyan)

            if engine.mode == .blitz {
                statPill(title: "SÜRE", value: "\(engine.timeRemaining)s", color: engine.timeRemaining <= 10 ? .red : .orange)
            } else if engine.mode == .survival {
                statPill(title: "CAN", value: String(repeating: "❤️", count: max(0, engine.lives)), color: .pink)
            } else {
                statPill(title: "SERİ", value: "x\(engine.combo)", color: .yellow)
            }
        }
    }

    private func statPill(title: String, value: String, color: Color) -> some View {
        HStack(spacing: 6) {
            Text(title)
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(.white.opacity(0.55))
            Text(value)
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .foregroundStyle(color)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private var gameOverSheet: some View {
        let shareText = "🧭 İlRadar (\(engine.mode.rawValue))\nSkor: \(engine.score) • Bulunan: \(engine.foundIDs.count)/81"

        return VStack(spacing: 18) {
            Image(systemName: "trophy.fill")
                .font(.system(size: 46))
                .foregroundStyle(.yellow)

            Text("Tur Tamamlandı!")
                .font(.title2.bold())

            Text("Skor: \(engine.score) • Bulunan İl: \(engine.foundIDs.count)/81")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            HStack(spacing: 12) {
                ShareLink(item: shareText) {
                    Label("Skoru Paylaş", systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                }

                Button {
                    engine.startNewGame(mode: engine.mode)
                } label: {
                    Text("Tekrar Oyna")
                        .bold()
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(.cyan, in: RoundedRectangle(cornerRadius: 12))
                        .foregroundStyle(.black)
                }
            }
            .padding(.horizontal)
        }
        .padding()
    }
}

// MARK: - Ustalık Pasaportu Ekranı
struct PassportView: View {
    let passport: PassportStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("Genel İlerleme") {
                    HStack {
                        Text("Uzmanlaşılan İl")
                        Spacer()
                        Text("\(passport.masteredIDs.count) / 81")
                            .bold()
                            .foregroundStyle(.cyan)
                    }
                    HStack {
                        Text("En İyi 60sn Blitz Skoru")
                        Spacer()
                        Text("\(passport.bestBlitzScore)")
                            .bold()
                    }
                    HStack {
                        Text("En Uzun 3 Can Serisi")
                        Spacer()
                        Text("\(passport.bestSurvivalStreak) il")
                            .bold()
                    }
                }

                Section("Bölge Bazlı Ustalık") {
                    ForEach(TurkeyRegion.allCases) { region in
                        let regionProvinces = TurkeyData.provinces.filter { $0.region == region }
                        let masteredCount = regionProvinces.filter { passport.masteredIDs.contains($0.id) }.count

                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Circle()
                                    .fill(region.color)
                                    .frame(width: 10, height: 10)
                                Text(region.rawValue)
                                    .font(.subheadline.bold())
                                Spacer()
                                Text("\(masteredCount)/\(regionProvinces.count)")
                                    .font(.caption.bold())
                                    .foregroundStyle(.secondary)
                            }
                            ProgressView(value: Double(masteredCount), total: Double(regionProvinces.count))
                                .tint(region.color)
                        }
                        .padding(.vertical, 4)
                    }
                }

                Section {
                    Button("İlerlemeyi Sıfırla", role: .destructive) {
                        passport.resetProgress()
                    }
                }
            }
            .navigationTitle("Ustalık Pasaportu")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Kapat") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}
