import SwiftUI
import Observation
import UIKit

@Observable
final class GameEngine {
    var mode: GameMode = .classic
    var foundIDs: Set<Int> = []
    var currentTarget: Province?
    var lastFoundID: Int?
    var wrongFlashID: Int?

    var score: Int = 0
    var combo: Int = 0
    var lives: Int = 3
    var timeRemaining: Int = 60
    var isGameOver: Bool = false
    var isWaitingToStart: Bool = false

    var promptBadge: String = "HEDEF İL"
    var promptTitle: String = ""
    var feedbackBanner: String?

    private var timer: Timer?
    private let passport: PassportStore

    init(passport: PassportStore) {
        self.passport = passport
        startNewGame(mode: .classic)
    }

    func startNewGame(mode: GameMode) {
        timer?.invalidate()
        self.mode = mode
        self.foundIDs = []
        self.lastFoundID = nil
        self.wrongFlashID = nil
        self.score = 0
        self.combo = 0
        self.lives = 3
        self.timeRemaining = 60
        self.isGameOver = false
        self.feedbackBanner = nil

        if mode == .blitz {
            isWaitingToStart = true
            promptBadge = "60SN BLİTZ"
            promptTitle = "Başlamak için haritaya dokun"
            currentTarget = nil
        } else {
            isWaitingToStart = false
            pickNextTarget()
        }
    }

    func triggerBlitzStart() {
        guard mode == .blitz, isWaitingToStart else { return }
        isWaitingToStart = false
        pickNextTarget()

        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self else { return }
            if self.timeRemaining > 0 {
                self.timeRemaining -= 1
            } else {
                self.finishGame()
            }
        }
    }

    func pickNextTarget() {
        let remaining = TurkeyData.provinces.filter { !foundIDs.contains($0.id) }
        currentTarget = remaining.randomElement()
        if currentTarget == nil {
            finishGame()
        } else {
            updatePrompt()
        }
    }

    func updatePrompt() {
        guard let t = currentTarget else { return }
        switch mode {
        case .classic, .blindMap, .survival:
            promptBadge = "HARİTADA BUL"
            promptTitle = t.name
        case .blitz:
            promptBadge = "60SN BLİTZ"
            promptTitle = t.name
        case .plateHunt:
            promptBadge = "PLAKA AVI"
            promptTitle = "\(t.plateString) Plakalı İl"
        case .detective:
            promptBadge = "İPUCUNDAN BUL"
            promptTitle = t.clue
        case .heritage:
            promptBadge = "KÜLTÜR & MİRAS"
            promptTitle = t.heritage
        }
    }

    func handleMapTap(_ tapped: Province) {
        if mode == .blitz && isWaitingToStart {
            triggerBlitzStart()
            return
        }

        guard !isGameOver, let target = currentTarget else { return }

        if tapped.id == target.id {
            registerSuccess(for: target)
            pickNextTarget()
        } else {
            registerMistake(tapped: tapped, expected: target)
        }
    }

    func skipCurrent() {
        guard !isGameOver, !isWaitingToStart else { return }
        // Pas geçince seri (combo) bozulmaz
        if let t = currentTarget {
            showBanner("Atlandı: \(t.plateString) \(t.name)")
        }
        pickNextTarget()
    }

    private func registerSuccess(for province: Province) {
        foundIDs.insert(province.id)
        lastFoundID = province.id
        passport.markMastered(province.id)

        combo += 1
        let bonus = min(combo * 10, 100)
        score += 100 + bonus

        if mode == .blitz, score > passport.bestBlitzScore {
            passport.bestBlitzScore = score
        }
        if mode == .survival, foundIDs.count > passport.bestSurvivalStreak {
            passport.bestSurvivalStreak = foundIDs.count
        }

        hapticSuccess()
        showBanner("✓ \(province.plateString) \(province.name) (+\(100 + bonus))")

        if foundIDs.count == 81 {
            finishGame()
        }
    }

    private func registerMistake(tapped: Province, expected: Province) {
        combo = 0
        wrongFlashID = tapped.id
        hapticError()

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { [weak self] in
            if self?.wrongFlashID == tapped.id {
                self?.wrongFlashID = nil
            }
        }

        if mode == .survival {
            lives -= 1
            if lives <= 0 {
                showBanner("Bitti! Doğru yer: \(expected.name)")
                finishGame()
                return
            }
        }

        showBanner("✗ Orası \(tapped.name) (\(tapped.plateString))")
    }

    private func showBanner(_ text: String) {
        feedbackBanner = text
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) { [weak self] in
            if self?.feedbackBanner == text {
                self?.feedbackBanner = nil
            }
        }
    }

    private func finishGame() {
        timer?.invalidate()
        isGameOver = true
        hapticSuccess()
    }

    private func hapticSuccess() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }

    private func hapticError() {
        UINotificationFeedbackGenerator().notificationOccurred(.error)
    }
}
