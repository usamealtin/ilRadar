import SwiftUI
import UIKit

struct TurkeyMapView: View {
    let provinces: [Province]
    let foundIDs: Set<Int>
    let wrongFlashID: Int?
    let highlightedID: Int?
    let isBlindMode: Bool
    let isTapMode: Bool
    let onProvinceTap: (Province) -> Void

    @State private var scale: CGFloat = 1.0
    @State private var offset: CGSize = .zero

    // ÖĞRETİCİ NOT 1: 81 ilin çizim yollarını her karede yeniden hesaplamak yerine önbellekte tutuyoruz
    @State private var cachedSize: CGSize = .zero
    @State private var cachedPaths: [Int: Path] = [:]
    @State private var cachedCenters: [Int: CGPoint] = [:]

    private let geometry = TurkeyMapGeometry.shared

    var body: some View {
        GeometryReader { geo in
            let mapSize = geo.size

            ZStack(alignment: .topTrailing) {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(red: 0.05, green: 0.10, blue: 0.19),
                                Color(red: 0.08, green: 0.15, blue: 0.27)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                            .strokeBorder(.white.opacity(0.14), lineWidth: 1)
                    )

                if geometry.polygons.isEmpty {
                    VStack(spacing: 6) {
                        Image(systemName: "map")
                            .font(.title2)
                            .foregroundStyle(.cyan)
                        Text("tr-cities.geojson dosyası bulunamadı")
                            .font(.caption.bold())
                            .foregroundStyle(.white.opacity(0.8))
                    }
                    .frame(width: mapSize.width, height: mapSize.height)
                } else {
                    ZStack {
                        Canvas { context, size in
                            // ÖĞRETİCİ NOT 2: Tüm noktaları tek tek çarpmak yerine ekran kartına (GPU)
                            // tek seferde yakınlaştırma ve kaydırma matrisi uyguluyoruz.
                            var mapContext = context
                            let cx = size.width / 2
                            let cy = size.height / 2
                            mapContext.translateBy(x: cx + offset.width, y: cy + offset.height)
                            mapContext.scaleBy(x: scale, y: scale)
                            mapContext.translateBy(x: -cx, y: -cy)

                            for province in provinces {
                                guard let path = cachedPaths[province.id] else { continue }

                                let isFound = foundIDs.contains(province.id)
                                let isWrong = wrongFlashID == province.id
                                let isHighlighted = highlightedID == province.id

                                let fillColor: Color = {
                                    if isWrong { return .red.opacity(0.85) }
                                    if isHighlighted { return province.region.color }
                                    if isFound { return province.region.color.opacity(0.82) }
                                    if isBlindMode { return Color.white.opacity(0.10) }
                                    return province.region.color.opacity(0.24)
                                }()

                                let strokeColor: Color = {
                                    if isWrong { return .white }
                                    if isHighlighted { return .white }
                                    if isFound { return .white.opacity(0.80) }
                                    return .white.opacity(0.35)
                                }()

                                mapContext.fill(path, with: .color(fillColor))
                                // Çizgi kalınlığını scale'e bölerek yakınlaştırınca sınırların kalınlaşmasını önlüyoruz
                                mapContext.stroke(
                                    path,
                                    with: .color(strokeColor),
                                    style: StrokeStyle(
                                        lineWidth: (isHighlighted ? 1.8 : 0.9) / scale,
                                        lineJoin: .round
                                    )
                                )
                            }

                            // Şehir isimlerini ekran koordinatında çizerek her zaman jilet gibi net tutuyoruz
                            for province in provinces where foundIDs.contains(province.id) {
                                guard let baseCenter = cachedCenters[province.id] else { continue }
                                let screenPos = CGPoint(
                                    x: (baseCenter.x - cx) * scale + cx + offset.width,
                                    y: (baseCenter.y - cy) * scale + cy + offset.height
                                )
                                let labelString = scale >= 2.0 ? province.name : province.plateString
                                let fontSize = min(13.0, max(7.5, 8.0 * sqrt(scale)))
                                let text = Text(labelString)
                                    .font(.system(size: fontSize, weight: .bold, design: .rounded))
                                    .foregroundColor(.white)

                                context.draw(text, at: screenPos, anchor: .center)
                            }
                        }
                        .allowsHitTesting(false)

                        MapGestureOverlay(
                            scale: $scale,
                            offset: $offset,
                            canvasSize: mapSize,
                            onTap: { point in
                                handleTap(at: point, in: mapSize)
                            }
                        )
                    }
                    .frame(width: mapSize.width, height: mapSize.height)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .onAppear {
                        rebuildCacheIfNeeded(for: mapSize)
                    }
                    .onChange(of: mapSize) { _, newSize in
                        rebuildCacheIfNeeded(for: newSize)
                    }
                }

                if scale > 1.05 || hypot(offset.width, offset.height) > 15 {
                    Button {
                        withAnimation(.spring(duration: 0.25)) {
                            scale = 1.0
                            offset = .zero
                        }
                    } label: {
                        Label("Sıfırla", systemImage: "arrow.up.left.and.arrow.down.right")
                            .font(.caption.bold())
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(.ultraThinMaterial, in: Capsule())
                            .foregroundStyle(.white)
                    }
                    .padding(12)
                }
            }
        }
    }

    // MARK: - Önbellek Oluşturucu (Sadece ekran boyutu değiştiğinde 1 kez çalışır)
    private func rebuildCacheIfNeeded(for size: CGSize) {
        guard size.width > 0, size.height > 0, size != cachedSize else { return }

        let topClearance: CGFloat = 68
        let sidePadding: CGFloat = 12
        let bottomPadding: CGFloat = 14

        let availW = max(size.width - sidePadding * 2, 10)
        let availH = max(size.height - topClearance - bottomPadding, 10)
        let aspect = max(geometry.aspectRatio, 2.0)

        let drawW: CGFloat
        let drawH: CGFloat
        if availW / availH > aspect {
            drawH = availH
            drawW = availH * aspect
        } else {
            drawW = availW
            drawH = availW / aspect
        }

        let originX = (size.width - drawW) / 2
        let originY = topClearance + (availH - drawH) / 2

        var newPaths: [Int: Path] = [:]
        var newCenters: [Int: CGPoint] = [:]

        for province in provinces {
            guard let polyData = geometry.polygons[province.id] else { continue }
            var path = Path()
            for ring in polyData.rings {
                guard let first = ring.first else { continue }
                path.move(to: CGPoint(x: originX + first.x * drawW, y: originY + first.y * drawH))
                for pt in ring.dropFirst() {
                    path.addLine(to: CGPoint(x: originX + pt.x * drawW, y: originY + pt.y * drawH))
                }
                path.closeSubpath()
            }
            newPaths[province.id] = path
            newCenters[province.id] = CGPoint(
                x: originX + polyData.center.x * drawW,
                y: originY + polyData.center.y * drawH
            )
        }

        cachedPaths = newPaths
        cachedCenters = newCenters
        cachedSize = size
    }

    // ÖĞRETİCİ NOT 3: Tıklanan ekran noktasını ters formülle temel harita koordinatına çeviriyoruz
    private func handleTap(at location: CGPoint, in size: CGSize) {
        let cx = size.width / 2
        let cy = size.height / 2
        let basePoint = CGPoint(
            x: (location.x - cx - offset.width) / scale + cx,
            y: (location.y - cy - offset.height) / scale + cy
        )

        for province in provinces {
            if let path = cachedPaths[province.id], path.contains(basePoint) {
                onProvinceTap(province)
                return
            }
        }

        var closest: Province?
        var minDist: CGFloat = .greatestFiniteMagnitude
        for province in provinces {
            guard let center = cachedCenters[province.id] else { continue }
            let d = hypot(basePoint.x - center.x, basePoint.y - center.y)
            if d < minDist {
                minDist = d
                closest = province
            }
        }

        if let target = closest, minDist <= (18.0 / scale) {
            onProvinceTap(target)
        }
    }
}

// MARK: - Eşzamanlı Çoklu Dokunma (Pinch + 1/2 Parmak Pan + Tap) Yöneticisi
private struct MapGestureOverlay: UIViewRepresentable {
    @Binding var scale: CGFloat
    @Binding var offset: CGSize
    let canvasSize: CGSize
    let onTap: (CGPoint) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .clear
        view.isMultipleTouchEnabled = true

        let pinch = UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePinch(_:)))
        pinch.delegate = context.coordinator

        let pan = UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePan(_:)))
        pan.minimumNumberOfTouches = 1
        pan.maximumNumberOfTouches = 2
        pan.delegate = context.coordinator

        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTap(_:)))
        tap.delegate = context.coordinator

        view.addGestureRecognizer(pinch)
        view.addGestureRecognizer(pan)
        view.addGestureRecognizer(tap)
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        context.coordinator.parent = self
    }

    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        var parent: MapGestureOverlay

        init(parent: MapGestureOverlay) {
            self.parent = parent
        }

        func gestureRecognizer(
            _ gestureRecognizer: UIGestureRecognizer,
            shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer
        ) -> Bool {
            let isPinchOrPan1 = gestureRecognizer is UIPinchGestureRecognizer || gestureRecognizer is UIPanGestureRecognizer
            let isPinchOrPan2 = otherGestureRecognizer is UIPinchGestureRecognizer || otherGestureRecognizer is UIPanGestureRecognizer
            return isPinchOrPan1 && isPinchOrPan2
        }

        @objc func handlePinch(_ recognizer: UIPinchGestureRecognizer) {
            guard let view = recognizer.view else { return }

            if recognizer.state == .changed {
                let oldScale = parent.scale
                let newScale = min(max(oldScale * recognizer.scale, 1.0), 6.0)
                let deltaScale = newScale / oldScale

                let focal = recognizer.location(in: view)
                let cx = parent.canvasSize.width / 2
                let cy = parent.canvasSize.height / 2

                let newOffsetX = (focal.x - cx) - ((focal.x - cx) - parent.offset.width) * deltaScale
                let newOffsetY = (focal.y - cy) - ((focal.y - cy) - parent.offset.height) * deltaScale

                parent.scale = newScale
                parent.offset = CGSize(width: newOffsetX, height: newOffsetY)
                recognizer.scale = 1.0
            } else if recognizer.state == .ended || recognizer.state == .cancelled {
                if parent.scale <= 1.03 {
                    withAnimation(.spring(duration: 0.25)) {
                        parent.scale = 1.0
                        parent.offset = .zero
                    }
                }
            }
        }

        @objc func handlePan(_ recognizer: UIPanGestureRecognizer) {
            guard let view = recognizer.view else { return }

            if recognizer.state == .changed {
                let translation = recognizer.translation(in: view)
                parent.offset = CGSize(
                    width: parent.offset.width + translation.x,
                    height: parent.offset.height + translation.y
                )
                recognizer.setTranslation(.zero, in: view)
            } else if recognizer.state == .ended || recognizer.state == .cancelled {
                if parent.scale <= 1.03 && hypot(parent.offset.width, parent.offset.height) < 15 {
                    withAnimation(.spring(duration: 0.2)) {
                        parent.offset = .zero
                    }
                }
            }
        }

        @objc func handleTap(_ recognizer: UITapGestureRecognizer) {
            guard let view = recognizer.view, recognizer.state == .ended else { return }
            let point = recognizer.location(in: view)
            parent.onTap(point)
        }
    }
}
