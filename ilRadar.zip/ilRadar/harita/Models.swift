import SwiftUI
import Observation

// MARK: - Coğrafi Bölgeler
enum TurkeyRegion: String, CaseIterable, Identifiable, Codable {
    case marmara = "Marmara"
    case ege = "Ege"
    case akdeniz = "Akdeniz"
    case icAnadolu = "İç Anadolu"
    case karadeniz = "Karadeniz"
    case doguAnadolu = "Doğu Anadolu"
    case guneydogu = "Güneydoğu Anadolu"

    var id: String { rawValue }

    var color: Color {
        switch self {
        case .marmara: return Color(red: 0.25, green: 0.62, blue: 0.96)
        case .ege: return Color(red: 0.18, green: 0.80, blue: 0.72)
        case .akdeniz: return Color(red: 0.98, green: 0.56, blue: 0.22)
        case .icAnadolu: return Color(red: 0.95, green: 0.77, blue: 0.22)
        case .karadeniz: return Color(red: 0.22, green: 0.76, blue: 0.45)
        case .doguAnadolu: return Color(red: 0.68, green: 0.45, blue: 0.95)
        case .guneydogu: return Color(red: 0.92, green: 0.36, blue: 0.46)
        }
    }
}

// MARK: - Tamamen Dokunmatik Oyun Modları
enum GameMode: String, CaseIterable, Identifiable {
    case classic = "81 İl"
    case plateHunt = "Plaka Avı"
    case blindMap = "Kör Harita"
    case detective = "Dedektif"
    case heritage = "Kültür & Miras"
    case blitz = "60sn Blitz"
    case survival = "3 Can"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .classic: return "map.fill"
        case .plateHunt: return "number.square.fill"
        case .blindMap: return "eye.slash.fill"
        case .detective: return "magnifyingglass"
        case .heritage: return "building.columns.fill"
        case .blitz: return "bolt.fill"
        case .survival: return "heart.fill"
        }
    }
}

// MARK: - İl Modeli
struct Province: Identifiable, Hashable {
    let id: Int              // Plaka kodu (1...81)
    let name: String
    let region: TurkeyRegion
    let lat: Double
    let lon: Double
    let clue: String
    let heritage: String

    var plateString: String {
        String(format: "%02d", id)
    }

    var normalizedPoint: CGPoint {
        let minLon = 25.5, maxLon = 44.9
        let minLat = 35.7, maxLat = 42.2
        let x = (lon - minLon) / (maxLon - minLon)
        let y = 1.0 - ((lat - minLat) / (maxLat - minLat))
        return CGPoint(x: x, y: y)
    }
}

// MARK: - 81 İl Veritabanı
enum TurkeyData {
    static let provinces: [Province] = [
        Province(id: 1, name: "Adana", region: .akdeniz, lat: 37.00, lon: 35.32, clue: "Seyhan ve Ceyhan nehirlerinin suladığı Çukurova'nın merkezi.", heritage: "Taşköprü ve Varda Köprüsü"),
        Province(id: 2, name: "Adıyaman", region: .guneydogu, lat: 37.76, lon: 38.28, clue: "Güneşin doğuşunun en etkileyici izlendiği zirveye ev sahipliği yapar.", heritage: "Nemrut Dağı Dev Heykelleri"),
        Province(id: 3, name: "Afyonkarahisar", region: .ege, lat: 38.75, lon: 30.54, clue: "Termal kaynakları, mermeri ve kavşak noktası konumuyla bilinir.", heritage: "Karahisar Kalesi ve Frig Vadisi"),
        Province(id: 4, name: "Ağrı", region: .doguAnadolu, lat: 39.72, lon: 43.05, clue: "Türkiye'nin en yüksek zirvesi sınırları içerisindedir.", heritage: "İshak Paşa Sarayı"),
        Province(id: 5, name: "Amasya", region: .karadeniz, lat: 40.65, lon: 35.83, clue: "Yeşilırmak kıyısında kurulu, Osmanlı şehzadelerinin eğitim şehri.", heritage: "Kral Kaya Mezarları ve Yalıboyu Evleri"),
        Province(id: 6, name: "Ankara", region: .icAnadolu, lat: 39.93, lon: 32.85, clue: "Cumhuriyetin kalbi, bozkırın ortasındaki başkent.", heritage: "Anıtkabir ve Gordion Antik Kenti"),
        Province(id: 7, name: "Antalya", region: .akdeniz, lat: 36.89, lon: 30.71, clue: "Toroslar ile Akdeniz arasına uzanan turizm başkenti.", heritage: "Aspendos Tiyatrosu ve Kaleiçi"),
        Province(id: 8, name: "Artvin", region: .karadeniz, lat: 41.18, lon: 41.82, clue: "Sarp vadileri, yaylaları ve Çoruh Nehri ile ünlü sınır ili.", heritage: "Karagöl ve Mençuna Şelalesi"),
        Province(id: 9, name: "Aydın", region: .ege, lat: 37.85, lon: 27.84, clue: "Büyük Menderes havzasında inciri ve antik kentleriyle öne çıkar.", heritage: "Afrodisias ve Didyma Apollon Tapınağı"),
        Province(id: 10, name: "Balıkesir", region: .marmara, lat: 39.65, lon: 27.88, clue: "Hem Marmara'ya hem Ege'ye kıyısı bulunan iki denizli şehir.", heritage: "Kazdağları ve Cunda Adası"),
        Province(id: 11, name: "Bilecik", region: .marmara, lat: 40.14, lon: 29.98, clue: "Osmanlı Beyliği'nin temellerinin atıldığı Söğüt ilçesine sahiptir.", heritage: "Şeyh Edebali Türbesi"),
        Province(id: 12, name: "Bingöl", region: .doguAnadolu, lat: 38.88, lon: 40.50, clue: "Adını buzul göllerinden alan Doğu Anadolu şehri.", heritage: "Yüzen Adalar Tabiat Anıtı"),
        Province(id: 13, name: "Bitlis", region: .doguAnadolu, lat: 38.40, lon: 42.11, clue: "Van Gölü'nün batı kıyısında yer alan tarihi kent.", heritage: "Ahlat Selçuklu Meydan Mezarlığı"),
        Province(id: 14, name: "Bolu", region: .karadeniz, lat: 40.73, lon: 31.61, clue: "İstanbul ile Ankara arasında ormanları ve aşçılarıyla ünlü durak.", heritage: "Abant ve Yedigöller Milli Parkı"),
        Province(id: 15, name: "Burdur", region: .akdeniz, lat: 37.72, lon: 30.29, clue: "Göller Yöresi'nde yer alır, turkuaz renkli krater gölüyle ünlüdür.", heritage: "Sagalassos Antik Kenti ve Salda Gölü"),
        Province(id: 16, name: "Bursa", region: .marmara, lat: 40.19, lon: 29.06, clue: "Uludağ'ın eteklerinde kurulu, Osmanlı'nın ilk başkenti.", heritage: "Ulu Camii ve Cumalıkızık"),
        Province(id: 17, name: "Çanakkale", region: .marmara, lat: 40.15, lon: 26.41, clue: "Asya ve Avrupa'yı kendi adını taşıyan boğazla birleştirir.", heritage: "Troya Antik Kenti ve Gelibolu Yarımadası"),
        Province(id: 18, name: "Çankırı", region: .icAnadolu, lat: 40.60, lon: 33.62, clue: "Kaya tuzu mağaraları ve Ilgaz Dağı ile bilinen İç Anadolu ili.", heritage: "Tuz Mağarası ve Taş Mescit"),
        Province(id: 19, name: "Çorum", region: .karadeniz, lat: 40.55, lon: 34.95, clue: "Hitit İmparatorluğu'nun başkenti Hattuşa'ya ev sahipliği yapar.", heritage: "Hattuşa ve Alacahöyük"),
        Province(id: 20, name: "Denizli", region: .ege, lat: 37.77, lon: 29.09, clue: "Beyaz travertenleri ve tekstil üretimiyle dünyaca tanınır.", heritage: "Pamukkale ve Hierapolis Antik Kenti"),
        Province(id: 21, name: "Diyarbakır", region: .guneydogu, lat: 37.91, lon: 40.23, clue: "Dicle Nehri kıyısında bazalt taşlı devasa surlarıyla çevrilidir.", heritage: "Diyarbakır Surları ve Hevsel Bahçeleri"),
        Province(id: 22, name: "Edirne", region: .marmara, lat: 41.67, lon: 26.55, clue: "Türkiye'nin Avrupa'ya açılan sınır kapısı ve eski payitaht.", heritage: "Selimiye Camii ve Meriç Köprüsü"),
        Province(id: 23, name: "Elazığ", region: .doguAnadolu, lat: 38.67, lon: 39.22, clue: "Keban Barajı ve tarihi Harput yerleşimiyle öne çıkar.", heritage: "Harput Kalesi"),
        Province(id: 24, name: "Erzincan", region: .doguAnadolu, lat: 39.75, lon: 39.49, clue: "Fırat'ın kolu Karasu vadisinde, tulum peyniri ve bakırıyla bilinir.", heritage: "Girlevik Şelalesi ve Kemaliye"),
        Province(id: 25, name: "Erzurum", region: .doguAnadolu, lat: 39.90, lon: 41.27, clue: "Palandöken Dağı eteklerinde kış sporları ve tarihin buluşma noktası.", heritage: "Çifte Minareli Medrese"),
        Province(id: 26, name: "Eskişehir", region: .icAnadolu, lat: 39.77, lon: 30.52, clue: "Porsuk Çayı ve üniversite kültürüyle dinamik İç Anadolu kenti.", heritage: "Odunpazarı Evleri"),
        Province(id: 27, name: "Gaziantep", region: .guneydogu, lat: 37.06, lon: 37.38, clue: "UNESCO gastronomi şehri, fıstığı ve mozaikleriyle ünlü.", heritage: "Zeugma Mozaik Müzesi"),
        Province(id: 28, name: "Giresun", region: .karadeniz, lat: 40.91, lon: 38.39, clue: "Karadeniz'de üzerinde yaşanabilir tek adaya sahip fındık diyarı.", heritage: "Giresun Adası ve Kümbet Yaylası"),
        Province(id: 29, name: "Gümüşhane", region: .karadeniz, lat: 40.46, lon: 39.48, clue: "Adını tarihi gümüş madenlerinden alan dağlık Karadeniz ili.", heritage: "Karaca Mağarası ve Santa Harabeleri"),
        Province(id: 30, name: "Hakkari", region: .doguAnadolu, lat: 37.57, lon: 43.74, clue: "Türkiye'nin en güneydoğu ucunda Cilo Dağları ve buzullarıyla bilinir.", heritage: "Cilo-Sat Buzul Gölleri"),
        Province(id: 31, name: "Hatay", region: .akdeniz, lat: 36.20, lon: 36.16, clue: "Medeniyetler şehri, Asi Nehri kıyısında Türkiye'nin en güney noktası.", heritage: "St. Pierre Kilisesi ve Titus Tüneli"),
        Province(id: 32, name: "Isparta", region: .akdeniz, lat: 37.76, lon: 30.55, clue: "Gül bahçeleri ve Eğirdir Gölü ile ünlü Akdeniz şehri.", heritage: "Eğirdir Gölü ve Yazılı Kanyon"),
        Province(id: 33, name: "Mersin", region: .akdeniz, lat: 36.80, lon: 34.63, clue: "Türkiye'nin en büyük limanlarından birine sahip uzun sahil kenti.", heritage: "Kızkalesi ve Cennet-Cehennem Obrukları"),
        Province(id: 34, name: "İstanbul", region: .marmara, lat: 41.01, lon: 28.97, clue: "İki kıtayı birbirine bağlayan boğazın incisi metropol.", heritage: "Ayasofya, Topkapı Sarayı ve Tarihi Yarımada"),
        Province(id: 35, name: "İzmir", region: .ege, lat: 38.42, lon: 27.14, clue: "Ege'nin incisi, körfezi ve antik İyonya mirasıyla tanınır.", heritage: "Efes Antik Kenti ve Saat Kulesi"),
        Province(id: 36, name: "Kars", region: .doguAnadolu, lat: 40.60, lon: 43.09, clue: "Doğu Ekspresi'nin son durağı, Baltık mimarisi ve kaşarıyla ünlü.", heritage: "Ani Harabeleri ve Çıldır Gölü"),
        Province(id: 37, name: "Kastamonu", region: .karadeniz, lat: 41.38, lon: 33.78, clue: "Batı Karadeniz'de ahşap konakları ve Ilgaz-Küre dağlarıyla bilinir.", heritage: "Valla Kanyonu ve Mahmut Bey Camii"),
        Province(id: 38, name: "Kayseri", region: .icAnadolu, lat: 38.73, lon: 35.48, clue: "Erciyes Dağı'nın gölgesinde kadim ticaret ve sanayi merkezi.", heritage: "Kültepe Kaniş-Karum ve Erciyes"),
        Province(id: 39, name: "Kırklareli", region: .marmara, lat: 41.73, lon: 27.22, clue: "Trakya'nın kuzeydoğusunda Istranca Ormanları ve longozlarıyla ünlü.", heritage: "İğneada Longoz Ormanları"),
        Province(id: 40, name: "Kırşehir", region: .icAnadolu, lat: 39.14, lon: 34.16, clue: "Ahilik teşkilatının merkezi ve bozlak geleneğinin yurdu.", heritage: "Cacabey Medresesi"),
        Province(id: 41, name: "Kocaeli", region: .marmara, lat: 40.76, lon: 29.94, clue: "İzmit Körfezi çevresinde Türkiye sanayisinin lokomotifi.", heritage: "Kartepe ve Seka Park"),
        Province(id: 42, name: "Konya", region: .icAnadolu, lat: 37.87, lon: 32.48, clue: "Yüzölçümü bakımından Türkiye'nin en büyük ili.", heritage: "Mevlana Müzesi ve Çatalhöyük"),
        Province(id: 43, name: "Kütahya", region: .ege, lat: 39.42, lon: 29.98, clue: "Çini sanatı ve porseleniyle ünlü Ege şehri.", heritage: "Aizanoi Antik Kenti"),
        Province(id: 44, name: "Malatya", region: .doguAnadolu, lat: 38.35, lon: 38.31, clue: "Dünya kayısı üretiminin başkenti olan Doğu Anadolu ili.", heritage: "Arslantepe Höyüğü"),
        Province(id: 45, name: "Manisa", region: .ege, lat: 38.61, lon: 27.43, clue: "Spil Dağı eteklerinde üzümü ve şehzadeler tarihiyle bilinir.", heritage: "Sardes Antik Kenti"),
        Province(id: 46, name: "Kahramanmaraş", region: .akdeniz, lat: 37.58, lon: 36.93, clue: "Dondurması, biberi ve İstiklal Madalyalı kahramanlık tarihiyle ünlü.", heritage: "Germenicia Antik Kenti"),
        Province(id: 47, name: "Mardin", region: .guneydogu, lat: 37.31, lon: 40.73, clue: "Mezopotamya ovasına bakan sarı kalker taşlı mimarisiyle büyüler.", heritage: "Deyrulzafaran Manastırı ve Dara Antik Kenti"),
        Province(id: 48, name: "Muğla", region: .ege, lat: 37.21, lon: 28.36, clue: "Bodrum, Marmaris ve Fethiye gibi koylarıyla Türkiye'nin en uzun kıyı şeridi.", heritage: "Ölüdeniz ve Kral Mezarları"),
        Province(id: 49, name: "Muş", region: .doguAnadolu, lat: 38.74, lon: 41.49, clue: "Geniş ovası ve baharda açan laleleriyle bilinen Doğu Anadolu ili.", heritage: "Murat Köprüsü"),
        Province(id: 50, name: "Nevşehir", region: .icAnadolu, lat: 38.62, lon: 34.71, clue: "Volkanik tüf kayaların şekillendirdiği peribacalarının merkezi.", heritage: "Kapadokya ve Göreme Açık Hava Müzesi"),
        Province(id: 51, name: "Niğde", region: .icAnadolu, lat: 37.96, lon: 34.68, clue: "Aladağlar ve Bolkar Dağları arasında elmasıyla ünlü şehir.", heritage: "Gümüşler Manastırı"),
        Province(id: 52, name: "Ordu", region: .karadeniz, lat: 40.98, lon: 37.88, clue: "Boztepe'den Karadeniz'e bakan, fındık ve yaylalarıyla ünlü il.", heritage: "Yason Burnu ve Perşembe Yaylası"),
        Province(id: 53, name: "Rize", region: .karadeniz, lat: 41.02, lon: 40.52, clue: "Türkiye'nin çay bahçesi ve en çok yağış alan yeşil ili.", heritage: "Ayder Yaylası ve Zil Kale"),
        Province(id: 54, name: "Sakarya", region: .marmara, lat: 40.77, lon: 30.40, clue: "Sapanca Gölü ve Karadeniz sahiliyle Marmara'nın doğu kapısı.", heritage: "Justinianus Köprüsü"),
        Province(id: 55, name: "Samsun", region: .karadeniz, lat: 41.28, lon: 36.33, clue: "Kızılırmak ve Yeşilırmak deltaları arasında Milli Mücadele'nin başlangıç noktası.", heritage: "Bandırma Vapuru ve Şahinkaya Kanyonu"),
        Province(id: 56, name: "Siirt", region: .guneydogu, lat: 37.93, lon: 41.94, clue: "Botan Vadisi üzerinde fıstığı ve büryan kebabıyla tanınır.", heritage: "Tillo ve Botan Vadisi"),
        Province(id: 57, name: "Sinop", region: .karadeniz, lat: 42.02, lon: 35.15, clue: "Anadolu'nun en kuzey ucu İnceburun'a sahip doğal liman kenti.", heritage: "Tarihi Sinop Cezaevi ve Hamsilos Koyu"),
        Province(id: 58, name: "Sivas", region: .icAnadolu, lat: 39.75, lon: 37.01, clue: "Selçuklu eserleri ve Cumhuriyet tarihindeki kongresiyle öne çıkar.", heritage: "Divriği Ulu Camii ve Darüşşifası"),
        Province(id: 59, name: "Tekirdağ", region: .marmara, lat: 40.98, lon: 27.51, clue: "Marmara Denizi kıyısında ayçiçeği tarlaları ve köftesiyle ünlü Trakya ili.", heritage: "Uçmakdere ve Rakoczi Müzesi"),
        Province(id: 60, name: "Tokat", region: .karadeniz, lat: 40.31, lon: 36.55, clue: "Yeşilırmak havzasında yazmacılığı ve yaprağıyla bilinen tarihi şehir.", heritage: "Ballıca Mağarası"),
        Province(id: 61, name: "Trabzon", region: .karadeniz, lat: 41.00, lon: 39.72, clue: "Doğu Karadeniz'in en büyük liman ve kültür merkezlerinden biri.", heritage: "Sümela Manastırı ve Uzungöl"),
        Province(id: 62, name: "Tunceli", region: .doguAnadolu, lat: 39.10, lon: 39.54, clue: "Munzur Vadisi ve yüksek okuryazarlık oranıyla dikkat çeken şehir.", heritage: "Munzur Vadisi Milli Parkı"),
        Province(id: 63, name: "Şanlıurfa", region: .guneydogu, lat: 37.16, lon: 38.79, clue: "Tarihin sıfır noktası kabul edilen neolitik tapınaklara ev sahipliği yapar.", heritage: "Göbeklitepe ve Balıklıgöl"),
        Province(id: 64, name: "Uşak", region: .ege, lat: 38.67, lon: 29.40, clue: "Türkiye'de ilk şeker fabrikasının kurulduğu, halılarıyla ünlü Ege ili.", heritage: "Ulubey Kanyonu ve Karun Hazineleri"),
        Province(id: 65, name: "Van", region: .doguAnadolu, lat: 38.49, lon: 43.38, clue: "Türkiye'nin en büyük gölüne adını veren, kahvaltısı ve kedisiyle ünlü şehir.", heritage: "Akdamar Kilisesi ve Van Kalesi"),
        Province(id: 66, name: "Yozgat", region: .icAnadolu, lat: 39.82, lon: 34.80, clue: "İç Anadolu'nun ortasında Türkiye'nin ilk milli parkı Çamlık'a sahiptir.", heritage: "Sarıkaya Roma Hamamı"),
        Province(id: 67, name: "Zonguldak", region: .karadeniz, lat: 41.45, lon: 31.79, clue: "Taşkömürü madenleriyle Türkiye sanayisine enerji veren Karadeniz ili.", heritage: "Gökgöl Mağarası"),
        Province(id: 68, name: "Aksaray", region: .icAnadolu, lat: 38.37, lon: 34.03, clue: "Tuz Gölü kıyısında ve Hasan Dağı eteklerinde yer alan İpek Yolu şehri.", heritage: "Ihlara Vadisi ve Sultanhanı Kervansarayı"),
        Province(id: 69, name: "Bayburt", region: .karadeniz, lat: 40.25, lon: 40.22, clue: "Çoruh Nehri kıyısında nüfus bakımından Türkiye'nin en sakin illerinden biri.", heritage: "Baksı Müzesi ve Bayburt Kalesi"),
        Province(id: 70, name: "Karaman", region: .icAnadolu, lat: 37.18, lon: 33.22, clue: "Karamanoğlu Mehmet Bey'in Türkçeyi resmi dil ilan ettiği şehir.", heritage: "Taşkale Tahıl Ambarları"),
        Province(id: 71, name: "Kırıkkale", region: .icAnadolu, lat: 39.84, lon: 33.51, clue: "Kızılırmak kıyısında savunma sanayisi ve rafinerisiyle gelişen il.", heritage: "Çeşnigir Köprüsü"),
        Province(id: 72, name: "Batman", region: .guneydogu, lat: 37.88, lon: 41.13, clue: "Türkiye'de ilk petrolün çıkarıldığı Raman Dağı'na ev sahipliği yapar.", heritage: "Hasankeyf"),
        Province(id: 73, name: "Şırnak", region: .guneydogu, lat: 37.51, lon: 42.46, clue: "Cudi ve Gabar dağları eteklerinde Irak ve Suriye'ye komşu sınır ili.", heritage: "Cizre Ulu Camii ve Mem u Zin Türbesi"),
        Province(id: 74, name: "Bartın", region: .karadeniz, lat: 41.63, lon: 32.33, clue: "Türkiye'de üzerinde ulaşım yapılabilen tek akarsuya sahip sahil kenti.", heritage: "Amasra Kalesi ve Güzelcehisar Lav Sütunları"),
        Province(id: 75, name: "Ardahan", region: .doguAnadolu, lat: 41.11, lon: 42.70, clue: "Kura Nehri'nin doğduğu, kışları sert geçen kuzeydoğu sınır ili.", heritage: "Şeytan Kalesi"),
        Province(id: 76, name: "Iğdır", region: .doguAnadolu, lat: 39.92, lon: 44.04, clue: "Ağrı Dağı'nın eteklerinde mikroklima iklimi sayesinde pamuk bile yetişen şehir.", heritage: "Tuzluca Tuz Mağaraları"),
        Province(id: 77, name: "Yalova", region: .marmara, lat: 40.65, lon: 29.27, clue: "Yüzölçümü bakımından Türkiye'nin en küçük ili.", heritage: "Yürüyen Köşk ve Termal Kaplıcaları"),
        Province(id: 78, name: "Karabük", region: .karadeniz, lat: 41.20, lon: 32.62, clue: "Demir-çelik fabrikası ve UNESCO mirası tarihi evleriyle ünlü.", heritage: "Safranbolu Evleri"),
        Province(id: 79, name: "Kilis", region: .guneydogu, lat: 36.71, lon: 37.11, clue: "Suriye sınırında zeytinyağı ve mutfak kültürüyle tanınan şehir.", heritage: "Ravanda Kalesi"),
        Province(id: 80, name: "Osmaniye", region: .akdeniz, lat: 37.07, lon: 36.24, clue: "Çukurova'nın doğusunda yer fıstığı ve kaleleriyle ünlü Akdeniz ili.", heritage: "Karatepe-Aslantaş Açık Hava Müzesi"),
        Province(id: 81, name: "Düzce", region: .karadeniz, lat: 40.84, lon: 31.16, clue: "1999 yılında il statüsü kazanan Türkiye'nin en genç 81. ili.", heritage: "Samandere Şelalesi ve Prusias ad Hypium")
    ]
}

// MARK: - Ustalık Pasaportu & Kalıcı Kayıt
@Observable
final class PassportStore {
    var masteredIDs: Set<Int> {
        didSet { save() }
    }
    var bestBlitzScore: Int {
        didSet { UserDefaults.standard.set(bestBlitzScore, forKey: "best_blitz") }
    }
    var bestSurvivalStreak: Int {
        didSet { UserDefaults.standard.set(bestSurvivalStreak, forKey: "best_survival") }
    }

    init() {
        let saved = UserDefaults.standard.array(forKey: "mastered_provinces") as? [Int] ?? []
        self.masteredIDs = Set(saved)
        self.bestBlitzScore = UserDefaults.standard.integer(forKey: "best_blitz")
        self.bestSurvivalStreak = UserDefaults.standard.integer(forKey: "best_survival")
    }

    func markMastered(_ id: Int) {
        masteredIDs.insert(id)
    }

    private func save() {
        UserDefaults.standard.set(Array(masteredIDs), forKey: "mastered_provinces")
    }

    func resetProgress() {
        masteredIDs.removeAll()
        bestBlitzScore = 0
        bestSurvivalStreak = 0
    }
}
