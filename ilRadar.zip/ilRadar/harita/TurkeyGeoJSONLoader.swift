import SwiftUI
import MapKit

struct ProvincePolygon: Identifiable {
    let id: Int                 // Plaka kodu (1...81)
    let rings: [[CGPoint]]      // Normalize (0...1) poligon halkaları
    let center: CGPoint         // Plaka etiketi için merkez koordinat
}

struct TurkeyMapGeometry {
    let polygons: [Int: ProvincePolygon]
    let aspectRatio: CGFloat

    static let shared: TurkeyMapGeometry = loadFromBundle()

    private static func loadFromBundle() -> TurkeyMapGeometry {
        let candidates = [
            ("tr-cities", "geojson"),
            ("tr-cities", "json"),
            ("tr-cities-utf8", "json"),
            ("turkey", "geojson"),
            ("turkey", "json")
        ]

        var fileURL: URL?
        for (name, ext) in candidates {
            if let url = Bundle.main.url(forResource: name, withExtension: ext) {
                fileURL = url
                break
            }
        }

        guard let url = fileURL,
              let data = try? Data(contentsOf: url),
              let decoded = try? MKGeoJSONDecoder().decode(data) else {
            return TurkeyMapGeometry(polygons: [:], aspectRatio: 2.25)
        }

        let cosLat = cos(39.0 * .pi / 180.0)
        var rawProvinces: [Int: [[[CGPoint]]]] = [:]

        var minX = Double.greatestFiniteMagnitude
        var maxX = -Double.greatestFiniteMagnitude
        var minY = Double.greatestFiniteMagnitude
        var maxY = -Double.greatestFiniteMagnitude

        for item in decoded {
            guard let feature = item as? MKGeoJSONFeature else { continue }

            var mkPolygons: [MKPolygon] = []
            for geom in feature.geometry {
                if let poly = geom as? MKPolygon {
                    mkPolygons.append(poly)
                } else if let multi = geom as? MKMultiPolygon {
                    mkPolygons.append(contentsOf: multi.polygons)
                }
            }

            var projectedPolys: [[[CGPoint]]] = []
            var sumLat = 0.0
            var sumLon = 0.0
            var totalPoints = 0

            for poly in mkPolygons {
                let coords = extractCoordinates(from: poly)
                guard coords.count >= 3 else { continue }

                var ringPoints: [CGPoint] = []
                ringPoints.reserveCapacity(coords.count)

                for c in coords {
                    sumLat += c.latitude
                    sumLon += c.longitude
                    totalPoints += 1

                    let px = c.longitude * cosLat
                    let py = -c.latitude
                    minX = min(minX, px)
                    maxX = max(maxX, px)
                    minY = min(minY, py)
                    maxY = max(maxY, py)
                    ringPoints.append(CGPoint(x: px, y: py))
                }
                projectedPolys.append([ringPoints])
            }

            guard !projectedPolys.isEmpty, totalPoints > 0 else { continue }

            let centroidLat = sumLat / Double(totalPoints)
            let centroidLon = sumLon / Double(totalPoints)

            // Önce isimden eşleştir, bulunamazsa doğrudan poligonun enlem-boylam merkezine en yakın ili seç
            let provinceID = resolveByName(feature: feature)
                ?? nearestProvinceID(lat: centroidLat, lon: centroidLon)

            if let id = provinceID {
                rawProvinces[id, default: []].append(contentsOf: projectedPolys)
            }
        }

        let spanX = max(maxX - minX, 0.0001)
        let spanY = max(maxY - minY, 0.0001)
        let aspect = CGFloat(spanX / spanY)

        var result: [Int: ProvincePolygon] = [:]

        for (id, polyList) in rawProvinces {
            var normalizedRings: [[CGPoint]] = []
            var largestRing: [CGPoint] = []

            for poly in polyList {
                for ring in poly {
                    let normRing = ring.map { pt in
                        CGPoint(
                            x: (pt.x - minX) / spanX,
                            y: (pt.y - minY) / spanY
                        )
                    }
                    normalizedRings.append(normRing)
                    if normRing.count > largestRing.count {
                        largestRing = normRing
                    }
                }
            }

            let center = boundingCenter(of: largestRing)
            result[id] = ProvincePolygon(id: id, rings: normalizedRings, center: center)
        }

        return TurkeyMapGeometry(polygons: result, aspectRatio: aspect)
    }

    private static func extractCoordinates(from polygon: MKPolygon) -> [CLLocationCoordinate2D] {
        let count = polygon.pointCount
        guard count > 0 else { return [] }
        var coords = Array(repeating: CLLocationCoordinate2D(), count: count)
        polygon.getCoordinates(&coords, range: NSRange(location: 0, length: count))
        return coords
    }

    private static func boundingCenter(of points: [CGPoint]) -> CGPoint {
        guard let first = points.first else { return CGPoint(x: 0.5, y: 0.5) }
        var minX = first.x, maxX = first.x
        var minY = first.y, maxY = first.y
        for p in points {
            minX = min(minX, p.x)
            maxX = max(maxX, p.x)
            minY = min(minY, p.y)
            maxY = max(maxY, p.y)
        }
        return CGPoint(x: (minX + maxX) / 2, y: (minY + maxY) / 2)
    }

    // MARK: - İsim ve Coğrafi Konum Tabanlı Kesin Eşleştirme
    private static func resolveByName(feature: MKGeoJSONFeature) -> Int? {
        guard let propData = feature.properties,
              let dict = try? JSONSerialization.jsonObject(with: propData) as? [String: Any] else {
            return nil
        }

        for value in dict.values {
            if let str = value as? String, let matchedID = matchProvinceName(str) {
                return matchedID
            }
        }
        return nil
    }

    private static func nearestProvinceID(lat: Double, lon: Double) -> Int? {
        var bestID: Int?
        var bestDist = Double.greatestFiniteMagnitude

        for province in TurkeyData.provinces {
            let dLat = province.lat - lat
            let dLon = (province.lon - lon) * cos(39.0 * .pi / 180.0)
            let dist = dLat * dLat + dLon * dLon
            if dist < bestDist {
                bestDist = dist
                bestID = province.id
            }
        }
        return bestID
    }

    private static func matchProvinceName(_ raw: String) -> Int? {
        let clean = normalize(raw)
        let aliases: [String: Int] = [
            "afyon": 3,
            "icel": 33,
            "kmaras": 46,
            "kahramanmaras": 46,
            "sanliurfa": 63,
            "urfa": 63,
            "gaziantep": 27,
            "antep": 27
        ]
        if let aliasID = aliases[clean] { return aliasID }

        return TurkeyData.provinces.first { normalize($0.name) == clean }?.id
    }

    private static func normalize(_ text: String) -> String {
        text.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "İ", with: "i")
            .replacingOccurrences(of: "I", with: "ı")
            .lowercased(with: Locale(identifier: "tr_TR"))
            .folding(options: .diacriticInsensitive, locale: Locale(identifier: "tr_TR"))
            .replacingOccurrences(of: "ı", with: "i")
            .replacingOccurrences(of: ".", with: "")
            .replacingOccurrences(of: " ", with: "")
    }
}
