//
//  haritaApp.swift
//  harita
//
//  Created by Usame Altın on 17.11.2026.
//

import SwiftUI

@main
struct haritaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
